<div class="conteudo">
	<h1>Página não encontrada</h1>
	<p>A página que você está tentando acessar não existe ou foi removida.</p>
	<p>Verifique o endereço digitado e tente novamente, ou entre em contato.</p>
	<img src="images/erro.jpg" title="Bacon" alt="Bacon" class="img">
</div>