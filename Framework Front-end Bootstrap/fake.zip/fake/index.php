<!DOCTYPE html>
<html>
	<head>
		<title>Fake Games</title>
		<meta character="utf-8">
		<meta name="description" content="Só game massa">
		<meta name="keywords" content="">

		<link href='https://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>
		<link href='https://fonts.googleapis.com/css?family=Anton' rel='stylesheet' type='text/css'>
		<link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
		<link rel="stylesheet" type="text/css" href="css/style.css">
		<link rel="stylesheet" type="text/css" href="colorbox.css">
		
		<script src="js/jquery-1.11.3.min.js" type="text/javascript"></script>
		<script src="js/jquery.colorbox-min.js" type="text/javascript"></script>
		<script src="js/jquery.cycle2.min.js" type="text/javascript"></script>
	</head>
	<body>
		<header>
			<div class="conteudo">
			  <a><img src="images/logo.png" class="logo" id="logo"></a>
				<nav id="menu-topo">
					<ul>
						<li>
							<a href="home" title="Home">Home</a>
						</li>
						<li>
							<a href="sobre" title="Sobre">Sobre</a>
						</li>
						<li>
							<a href="jogos" title="Jogos">Jogos</a>
						</li>
						<li>
							<a href="contato" title="Contato">Contato</a>
						</li>
					</ul>
				</nav>
			</div>
		</header>

		<?php
		  //recuperar o parametro enviado pelo htaccess
			$param = "home";
			if(isset($_GET["param"])){
				$param = $_GET["param"];
			}
			
			$pag="paginas/".$param.".php";
			if(file_exists($pag)){
				include_once($pag);
			}
			else {
				include_once("erro.php");
			}
		?>

		<footer class="clear">
			<p>Desenvolvido por Tidinha - Todos os direitos reservados</p>
			<p>
				<a href="http://www.facebook.com/tidinha" title="Facebook da Tidinha" class="fa fa-facebook-square fa-3x"></a>
				<a href="http://www.twitter.com" title="Twitter da Tidinha" class="fa fa-twitter-square fa-3x"></a>
				<a href="http:www.instagram.com" title="Instagram da Tidinha" class="fa fa-instagram fa-3x"></a>
			</p>
		</footer>
	</body>
</html>
