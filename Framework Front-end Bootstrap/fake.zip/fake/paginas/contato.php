<div class="clear"></div>

<div class="conteudo">
	<h1>Entre em contato</h1>
	<p>Para entrar em contato, por favor, preencha o formulário abaixo ou entre em contato através do e-mail 
		<a href="mailto:fake@fake.com">fake@fake.com</a> ou pelo telefone (49) 9999-9999.
	</p>
	<form name="form1" action="#" method="post" accept-charset="utf-8">
		<label for="nome">Digite seu nome:</label>
		<input type="text" name="nome" class="box" value="" placeholder="Digite seu nome" required>

		<label for="email">Digite seu e-mail:</label>
		<input type="email" name="email" required placeholder="Digite seu e-mail" class="box">

		<label for="mensagem">Mensagem:</label>
		<textarea name="mensagem" class="box" rows="5" required placeholder="Digite sua mensagem aqui"></textarea>

		<button type="button" class="btn">Enviar Mensagem</button>
	</form>

	<h2>Mapa</h2>
	<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3551.926667156395!2d-52.66315688541449!3d-27.09560808304915!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x94e4b4553bf3a0f1%3A0x3f5f3379e78a14f4!2sEfapi+Chapec%C3%B3!5e0!3m2!1spt-BR!2sbr!4v1450307897323" width="100%" height="350" frameborder="0" style="border:0" allowfullscreen></iframe>
</div>