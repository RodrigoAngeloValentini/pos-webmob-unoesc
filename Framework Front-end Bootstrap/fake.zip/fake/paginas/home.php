<div class="cycle-slideshow" data-cycle-next=".proximo" data-cycle-prev=".anterior">
	<img src="images/b1.jpg" alt="Banner 1" title="Banner 1" class="img">
	<img src="images/b2.jpg" alt="Banner 2" title="Banner 2" class="img">
	<img src="images/b3.jpg" alt="Banner 3" title="Banner 3" class="img">

	<a href="#" title="Anterior" class="anterior">
		<img src="images/prev.png" alt="Anterior" title="Anterior"> 
	</a>

	<a href="#" title="Próximo" class="proximo">
		<img src="images/next.png" alt="Próximo" title="Próximo">
	</a>
</div>

<div class="conteudo" id="conteudo-home">
	<h1>Destaques:</h1>
	<div class="jogo">
		<a href="jogos" title="Jogos">
			<img src="images/4p.png" class="img">
			<p>Assassins Creed Black Flag</p>
		</a>
	</div>

	<div class="jogo">
		<a href="jogos" title="Jogos">
			<img src="images/5p.png" class="img">
			<p>Mortal Kombat X</p>
		</a>
	</div>

	<div class="jogo">
		<a href="jogos" title="Jogos">
			<img src="images/7p.png" class="img">
			<p>Call of Duty Advanced Warfare</p>
		</a>
	</div>
</div>