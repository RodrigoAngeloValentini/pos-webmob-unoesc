<div class="clear"></div>
<div class="conteudo">
	<div class="jogo">
		<a href="images/6.png">
			<img src="images/6p.png" class="img">
		</a>
		<h2>FIFA 16</h2>
		<p>
			Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dignissimos nobis error, aspernatur, deleniti maxime facere quaerat ratione ut voluptatum quam dolorem nesciunt sapiente nostrum repellendus nihil hic blanditiis recusandae porro?
		</p>
	</div> <!-- primeiro lanche -->


	<div class="jogo">
		<a href="images/3.png">
			<img src="images/3p.png" class="img">
		</a>
		<h2>PES 2016</h2>
		<p>
			Lorem ipsum dolor sit amet, consectetur adipisicing elit. Numquam nemo dignissimos alias consectetur rem, doloribus sunt at quia, deleniti odit dolores quam fugit reiciendis ex qui quod omnis. Dicta, doloribus.
		</p>
	</div> <!-- segundo lanche -->


	<div class="jogo">
		<a href="images/4.png">
			<img src="images/4p.png" class="img">
		</a>
		<h2>Assassin's Creed</h2>
		<p>
			Lorem ipsum dolor sit amet, consectetur adipisicing elit. Omnis laudantium ea, reiciendis sit, eos, nam blanditiis harum dicta temporibus soluta illo aut nesciunt voluptate ipsam cumque dignissimos iure adipisci placeat.
		</p>
	</div> <!-- terceiro lanche -->



	<div class="jogo">
		<a href="images/5.png">
			<img src="images/5p.png" class="img">
		</a>
		<h2>Mortal Kombat X</h2>
		<p>
			Lorem ipsum dolor sit amet, consectetur adipisicing elit. Tenetur voluptates asperiores blanditiis praesentium id dolor ullam fugiat unde, facere repudiandae eos officiis debitis impedit, officia eligendi magni sit nulla obcaecati.
		</p>
	</div> <!-- quarto lanche -->

	<div class="jogo">
		<a href="images/7.png">
			<img src="images/7p.png" class="img">
		</a>
		<h2>Call of Duty AW</h2>
		<p>
			Lorem ipsum dolor sit amet, consectetur adipisicing elit. Enim corporis culpa beatae, eveniet deserunt nemo, perspiciatis suscipit eos error vel earum natus fugiat laboriosam nulla assumenda alias impedit. Reprehenderit, dolorem.
		</p>
	</div> <!-- quinto lanche -->


	<div class="jogo">
		<a href="images/8.png">
			<img src="images/8p.png" class="img">
		</a>
		<h2>GTA V</h2>
		<p>
			Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quo blanditiis molestiae odit molestias est ullam aperiam nihil culpa doloremque, earum quia autem nam, eos magni nemo obcaecati delectus eum aspernatur.
		</p>
	</div> <!-- sexto lanche -->
</div>

<script type="text/javascript">
	$(document).ready(function(){
		$(".jogo a").colorbox();
	});

</script>