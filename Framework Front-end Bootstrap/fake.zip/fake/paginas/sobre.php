<div class="clear"></div>

<div class="conteudo">
	<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sed quo quaerat ab libero officiis rerum eos eveniet eius fugit nesciunt, accusamus a cupiditate amet obcaecati, dolorem veritatis! Harum, necessitatibus, officia!</p>
	<h2>Vídeo</h2>
	<iframe width="960" height="500" src="https://www.youtube.com/embed/DmYPwxKgPvw" frameborder="0" allowfullscreen></iframe>
</div>