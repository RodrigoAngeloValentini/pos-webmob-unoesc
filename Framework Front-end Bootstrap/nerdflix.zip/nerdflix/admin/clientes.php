<?php
include "topo.php";
include "menu.php";
?>
<div class="well container">
  <h1>Cadastro de Clientes</h1>
  
  <form name="form1" method="post" action="salvar.php" novalidate>
    <fieldset>
      <legend>* Campos obrigatórios</legend>
      
      <div class="control-group">
        <label for="nome" class="control-label">Nome Completo* :</label>
        <div class="controls">
          <input type="text" name="nome" required placeholder="Digite seu nome completo" data-validation-required-message="Preencha o campo" class="form-control">
        </div>
      </div>
      
      <div class="control-group">
        <label for="email" class="control-label">E-mail* :</label>
        <div class="controls">
          <input type="email" name="email" required placeholder="Digite seu email" data-validation-required-message="Preencha o campo" data-validation-email-message="E-mail inválido" class="form-control">
        </div>
      </div>
      
      <div class="control-group">
        <label for="telefone" class="control-label">Telefone :</label>
        <div class="controls">
          <input type="tel" name="telefone" placeholder="Digite seu telefone com DDD" data-mask="(99) 9999-9999?9" class="form-control">
        </div>
      </div>
      
      <div class="control-group">
        <label for="cpf" class="control-label">CPF :</label>
        <div class="controls">
          <input type="text" name="telefone" placeholder="Digite seu cpf" required data-mask="999.999.999-99" data-validation-required-message="Preencha o campo" class="form-control">
        </div>
      </div>
      
      <div class="control-group">
        <label for="estadocivil" class="control-label">Estado Civil* :</label>
        <div class="controls">
          <select name="estadocivil" required data-validation-required-message="Selecione um estado civil" class="form-control">
            <option value=""></option>
            <option value="S">Solteiro (a)</option>
            <option value="C">Casado (a)</option>
            <option value="V">Viúvo (a)</option>
          </select>
        </div>
      </div>
      
      <div class="control-group">
        <label for="sexo" class="control-label">Sexo* :</label>
        <div class="controls">
          <input type="radio" name="sexo"  value="M" required required data-validation-required-message="Selecione um sexo">Masculino
          <input type="radio" name="sexo" value="F" required data-validation-required-message="Selecione um sexo">Feminino
        </div>
      </div>
      
      <div class="control-group">
        <label for="salario" class="control-label">Salário :</label>
        <div class="controls">
          <input type="text" name="salario" id="salario" class="form-control">
        </div>
      </div>
      
      <div class="control-group">
        <label for="data" class="control-label">Data de Nascimento :</label>
        <div class="controls">
          <input type="text" name="data" id="data" class="form-control" data-mask="99/99/9999">
        </div>
      </div>
      
      <button type="submit" class="btn btn-success pull-right"><i class="glyphicon glyphicon-ok"></i>Salvar</button>
    </fieldset>
  </form>
  <script type="text/javascript">
    $(function(){
      $("#salario").maskMoney({thousands:'.', decimal:","});
      $("#data").datepicker({format: 'dd//mm/yyyy '});
    });
  </script>
</div>

</body>
</html>