<?php include "topo.php" ?>
      <div class="well well-sm container">
        <h1 class="text-center"><img src="../images/logo.png" alt="Nerdflix" title="Nerdflix"></h1>
        
        <form name="login" method="post" action="home.php" novalidate>
            <div class="form-group control-group">
              <label for="login" class="control-label">Login:</label>
              <div class="input-group controls">
                <div class="input-group-addon"><i class="glyphicon glyphicon-user"></i></div>
                <input type="text" name="login" placeholder="Digite o Login" required data-validation-required-message="Digite seu login" class="form-control">
              </div>
            </div>
            
            <div class="form-group control-group">
              <label for="senha" class="control-label">Senha:</label>
              <div class="input-group controls">
                <div class="input-group-addon"><i class="glyphicon glyphicon-asterisk"></i></div>
                <input type="password" name="senha" placeholder="Digite a senha" required data-validation-required-message="Digite sua senha" class="form-control">
              </div>
            </div>
            
            <button type="submit" class="btn btn-primary pull-right">Logar</button>
        </form>
      </div>
  </body>
</html>