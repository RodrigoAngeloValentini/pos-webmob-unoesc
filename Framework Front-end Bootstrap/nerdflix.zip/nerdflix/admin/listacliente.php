<?php 
include "topo.php"; 
include "menu.php";
?>
  <div class="well container">
    <h1>Lista de clientes</h1>
    <table class="table table-bordered table-striped table-hover">
      <thead>
        <tr>
          <th>Nome</th>
          <th>E-mail</th>
          <th>Opcoes</th>
        </tr>
        <tbody>
          <tr>
            <td>Rodrigo Angelo</td>
            <td>teste@teste.com.br</td>
            <td>
              <a href="cliente.php" class="btn btn-success"><i class="glyphicon glyphicon-pencil"></i></a>
              <a href="cliente.php" class="btn btn-danger"><i class="glyphicon glyphicon-trash"></i></a>
            </td>
          </tr>
          <tr>
            <td>Rodrigo Angelo</td>
            <td>teste@teste.com.br</td>
            <td>
              <a href="cliente.php" class="btn btn-success"><i class="glyphicon glyphicon-pencil"></i></a>
              <a href="cliente.php" class="btn btn-danger"><i class="glyphicon glyphicon-trash"></i></a>
            </td>
          </tr>
          <tr>
            <td>Rodrigo Angelo</td>
            <td>teste@teste.com.br</td>
            <td>
              <a href="cliente.php" class="btn btn-success"><i class="glyphicon glyphicon-pencil"></i></a>
              <a href="cliente.php" class="btn btn-danger"><i class="glyphicon glyphicon-trash"></i></a>
            </td>
          </tr>
          <tr>
            <td>Rodrigo Angelo</td>
            <td>teste@teste.com.br</td>
            <td>
              <a href="cliente.php" class="btn btn-success"><i class="glyphicon glyphicon-pencil"></i></a>
              <a href="cliente.php" class="btn btn-danger"><i class="glyphicon glyphicon-trash"></i></a>
            </td>
          </tr>
        </tbody>
      </thead>
    </table>
  </div>
</body>
</html>