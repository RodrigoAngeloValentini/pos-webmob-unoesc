<nav class="navbar navbar-inverse navbar-fixed-top">
  <div class="navbar-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#menu">
        <i class="icon-bar"></i>
        <i class="icon-bar"></i>
        <i class="icon-bar"></i>
      </button>
      <a href="home.php" class="nav-brand">
        <img src="../images/logo.png">
      </a>
    </div>
  </div>
  
  <div class="collapse navbar-collapse" id="menu">
    <ul class="nav navbar-nav navbar-right">
      <li><a href="home.php"><i class="glyphicon glyphicon-home"></i>Home</a></li>
      <li class="dropdown">
        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
          <i class="glyphicon glyphicon-pencil"></i>
          Cadastros
          <i class="caret"></i>
        </a>
        <ul class="dropdown-menu">
          <li>
            <a href="clientes.php">Clientes</a>
          </li>
          <li>
            <a href="produtos.php">Produtos</a>
          </li>
        </ul> 
      </li>
      <li class="dropdown">
        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
          <i class="glyphicon glyphicon-folder-open"></i>
          Relatórios/Listas
          <i class="caret"></i>
        </a>
        <ul class="dropdown-menu">
          <li>
            <a href="listacliente.php">Cliente</a>
          </li>
        </ul> 
      </li>
      <li><a href="sair.php"><i class="glyphicon glyphicon-off"></i>Sair</a></li>
    </ul>
  </div>
</nav>