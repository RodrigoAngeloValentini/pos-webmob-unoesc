  <div class="container">
     <h1>A Centopéia Humana</h1>

      <ul class="breadcrumb">
          <li><a href="home">Página Inicial</a></li>
          <li><a href="lancamentos">Lançamentos</a></li>
          <li>A Centopéia Humana</li>
      </ul>
      <div class="row">

        <div class="col-xs-12 col-sm-12 col-md-4">    
            <div class="thumbnail">
              <img src="images/4.jpg" alt="Centopéia Humana">
            </div>
        </div>

        <div class="col-xs-12 col-sm-12 col-md-8">

          <h4>Título Original</h4> 
          <p>A Centopéia Humana</p>
          <h4>Gênero</h4> 
          <p>Terror</p>
          <h4>Duração</h4> 
          <p>90 Minutos</p>
          <h4>Ano de Lançamento</h4> 
          <p>2010</p>
          <h4>Sinopse</h4>
          <p>Duas jovens americanas, que estão em viagem pela Europa, encontram-se com o carro quebrado à noite numa floresta deserta da Alemanha. Elas andam pelo local em busca de ajuda quando encontram uma cidadezinha isolada. No dia seguinte, elas acordam trancafiadas num hospital abandonado junto com um homem japonês - logo antes de um senhor alemão entrar no quarto e identificar-se como um cirurgião aposentado. Ele pretende juntá-los num só corpo e realizar o antigo desejo doentio de criar uma centopéia humana.</p>

        </div>

      </div>
  </div>