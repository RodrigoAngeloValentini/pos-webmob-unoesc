<div class="container">
    <div class="row">
        <img src="images/404.png" alt="Imagem erro" class="img-responsive center-block">
    </div>
</div>