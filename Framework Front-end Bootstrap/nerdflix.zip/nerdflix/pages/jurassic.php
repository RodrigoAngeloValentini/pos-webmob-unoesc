  <div class="container">
     <h1>Jurassic World</h1>

      <ul class="breadcrumb">
          <li><a href="home">Página Inicial</a></li>
          <li><a href="lancamentos">Lançamentos</a></li>
          <li>Jurassic World</li>
      </ul>
      <div class="row">

        <div class="col-xs-12 col-sm-12 col-md-4">    
            <div class="thumbnail">
              <img src="images/1.jpg" alt="Jurassic Park">
            </div>
        </div>

        <div class="col-xs-12 col-sm-12 col-md-8">

          <h4>Título Original</h4> 
          <p>Jurassic World</p>
          <h4>Gênero</h4> 
          <p>Ação, Aventura, Ficção Científica</p>
          <h4>Duração</h4> 
          <p>125 Minutos</p>
          <h4>Ano de Lançamento</h4> 
          <p>2015</p>
          <h4>Sinopse</h4>
          <p>O Jurassic Park, localizado na ilha Nublar, enfim está aberto ao público. Com isso, as pessoas podem conferir shows acrobáticos com dinossauros e até mesmo fazer passeios bem perto deles, já que agora estão domesticados. Entretanto, a equipe chefiada pela doutora Claire (Bryce Dallas Howard) passa a fazer experiências genéticas com estes seres, de forma a criar novas espécies. Uma delas logo adquire inteligência bem mais alta, logo se tornando uma grande ameaça para a existência humana.</p>

        </div>

      </div>
  </div>