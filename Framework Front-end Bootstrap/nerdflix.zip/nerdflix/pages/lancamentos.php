<div class="container">
  
  <h1>Lançamentos:</h1>
  
  <ul class="breadcrumb">
    <li><a href="home">Página Inicial</a></li>
    <li>Lançamentos</li>
  </ul>
  
  <div class="row">
    <div class="col-xs-12 col-sm-12 col-md-3">
      <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12">
          <div class="panel panel-default">
            <div class="panel-heading">
              <h3 class="panel-title">Categorias</h3>
            </div>
           
            <ul class="list-group">
              <li class="list-group-item"><a href="#">Todas</a></li>
              <li class="list-group-item"><a href="#">Aventura</a></li>
              <li class="list-group-item"><a href="#">Ação</a></li>
              <li class="list-group-item"><a href="#">Terror</a></li>
              <li class="list-group-item"><a href="#">Românce</a></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
    <div class="col-xs-12 col-sm-12 col-md-9">
      <div class="row">
        <div class="col-xs-12 col-sm-6 col-md-3 text-center">
          <div class="thumbnail">
            <img src="images/1.jpg" alt="Jurassic Park">
            <h2>Jurassic Park</h2>
            <a href="jurassic" class="btn btn-danger btn-lg">Detalhes</a>
          </div>
        </div>
        <div class="col-xs-12 col-sm-6 col-md-3 text-center">
          <div class="thumbnail">
            <img src="images/2.jpg" alt="Terremoto">
            <h2>Terremoto</h2>
            <a href="terremoto" class="btn btn-danger btn-lg">Detalhes</a>
          </div>
        </div>
        <div class="col-xs-12 col-sm-6 col-md-3 text-center">
          <div class="thumbnail">
            <img src="images/3.jpg" alt="Minions">
            <h2>Minions</h2>
            <a href="minions" class="btn btn-danger btn-lg">Detalhes</a>
          </div>
        </div>
        <div class="col-xs-12 col-sm-6 col-md-3 text-center">
          <div class="thumbnail">
            <img src="images/4.jpg" alt="Centopéia Humana">
            <h2>Centopéia Humana</h2>
            <a href="centopeia" class="btn btn-danger btn-lg">Detalhes</a>
          </div>
        </div>
        <div class="col-xs-12 col-sm-6 col-md-3 text-center">
          <div class="thumbnail">
            <img src="images/1.jpg" alt="Jurassic Park">
            <h2>Jurassic Park</h2>
            <a href="jurassic" class="btn btn-danger btn-lg">Detalhes</a>
          </div>
        </div>
        <div class="col-xs-12 col-sm-6 col-md-3 text-center">
          <div class="thumbnail">
            <img src="images/2.jpg" alt="Terremoto">
            <h2>Terremoto</h2>
            <a href="terremoto" class="btn btn-danger btn-lg">Detalhes</a>
          </div>
        </div>
        <div class="col-xs-12 col-sm-6 col-md-3 text-center">
          <div class="thumbnail">
            <img src="images/3.jpg" alt="Minions">
            <h2>Minions</h2>
            <a href="minions" class="btn btn-danger btn-lg">Detalhes</a>
          </div>
        </div>
        <div class="col-xs-12 col-sm-6 col-md-3 text-center">
          <div class="thumbnail">
            <img src="images/4.jpg" alt="Centopéia Humana">
            <h2>Centopéia Humana</h2>
            <a href="centopeia" class="btn btn-danger btn-lg">Detalhes</a>
          </div>
        </div>
      </div>
    </div>
    
  </div>
</div>