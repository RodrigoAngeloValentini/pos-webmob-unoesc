  <div class="container">
     <h1>Minions</h1>

      <ul class="breadcrumb">
          <li><a href="home">Página Inicial</a></li>
          <li><a href="lancamentos">Lançamentos</a></li>
          <li>Minions</li>
      </ul>
      <div class="row">

        <div class="col-xs-12 col-sm-12 col-md-4">    
            <div class="thumbnail">
              <img src="images/3.jpg" alt="Minions">
            </div>
        </div>

        <div class="col-xs-12 col-sm-12 col-md-8">

          <h4>Título Original</h4> 
          <p>Minions</p>
          <h4>Gênero</h4> 
          <p>Animação, Família</p>
          <h4>Duração</h4> 
          <p>91 Minutos</p>
          <h4>Ano de Lançamento</h4> 
          <p>2015</p>
          <h4>Sinopse</h4>
          <p>Seres amarelos milenares, os minions têm uma missão: servir os maiores vilões. Em depressão desde a morte de seu antigo mestre, eles tentam encontrar um novo chefe. Três voluntários, Kevin, Stuart e Bob, vão até uma convenção de vilões nos Estados Unidos e lá se encantam com Scarlet Overkill (Sandra Bullock), que ambiciona ser a primeira mulher a dominar o mundo.</p>

        </div>

      </div>
  </div>