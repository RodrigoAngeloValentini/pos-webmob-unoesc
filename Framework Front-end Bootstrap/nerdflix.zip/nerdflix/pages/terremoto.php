  <div class="container">
     <h1>Terremoto - A Falha de San Andreas</h1>

      <ul class="breadcrumb">
          <li><a href="home">Página Inicial</a></li>
          <li><a href="lancamentos">Lançamentos</a></li>
          <li>Terremoto</li>
      </ul>
      <div class="row">

        <div class="col-xs-12 col-sm-12 col-md-4">    
            <div class="thumbnail">
              <img src="images/2.jpg" alt="Terremoto">
            </div>
        </div>

        <div class="col-xs-12 col-sm-12 col-md-8">

          <h4>Título Original</h4> 
          <p>Terremoto - A Falha de San Andreas</p>
          <h4>Gênero</h4> 
          <p>Ação, Aventura, Suspense</p>
          <h4>Duração</h4> 
          <p>116 Minutos</p>
          <h4>Ano de Lançamento</h4> 
          <p>2015</p>
          <h4>Sinopse</h4>
          <p>Um terremoto atinge a Califórnia e faz com que Ray (Dwayne Johnson), um bombeiro especializado em restates com helicópteros, tenha que percorrer o estado ao lado da ex-esposa (Carla Gugino) para resgatar a sua filha Blake (Alexandra Daddario), que tenha sobreviver em São Francisco com a ajuda de dois jovens irmãos.</p>

        </div>

      </div>
  </div>