package br.edu.unoesc.pos.exemploCalculadora;

public interface Operacao {

	int calcular(int x, int y);
}
