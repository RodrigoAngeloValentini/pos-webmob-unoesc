package br.edu.unoesc.pos.exemploInterface;

public interface AcessaPortal {

	String getNickname();
}
