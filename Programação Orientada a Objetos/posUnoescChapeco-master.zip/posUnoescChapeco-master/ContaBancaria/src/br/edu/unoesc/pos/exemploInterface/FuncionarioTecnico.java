package br.edu.unoesc.pos.exemploInterface;

public class FuncionarioTecnico {

}
