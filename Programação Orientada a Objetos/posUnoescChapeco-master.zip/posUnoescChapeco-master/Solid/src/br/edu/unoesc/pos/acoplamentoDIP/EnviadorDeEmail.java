package br.edu.unoesc.pos.acoplamentoDIP;

public class EnviadorDeEmail {

	public void enviaEmail(NotaFiscal nf) {
		System.out.println("Enviou email");
	}

}
