package br.edu.unoesc.pos.acoplamentoDIP;

public class Fatura {

	public double getValorMensal() {
		// TODO Auto-generated method stub
		return 0;
	}

}
