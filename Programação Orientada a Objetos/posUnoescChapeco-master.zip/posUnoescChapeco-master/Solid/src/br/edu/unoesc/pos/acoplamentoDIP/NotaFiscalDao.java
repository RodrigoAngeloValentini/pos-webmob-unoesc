package br.edu.unoesc.pos.acoplamentoDIP;

public class NotaFiscalDao {

	public void persiste(NotaFiscal nf) {
		System.out.println("salvou no banco");
	}

}
