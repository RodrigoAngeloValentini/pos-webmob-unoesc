package br.edu.unoesc.pos.coesao;

public interface CalculaSalarioFuncionario {

	double calcula(Funcionario funcionario);
}
