package br.edu.unoesc.pos.lsp;

public class ContaNaoRendeException extends RuntimeException {

	private static final long serialVersionUID = 924506122427960893L;

}
