package br.edu.unoesc.pos.ocp;

public class Compra {

	private Double valor;
	private String cidade;

	public Double getValor() {
		return valor;
	}

	public void setValor(Double valor) {
		this.valor = valor;
	}

	public String getCidade() {
		return this.cidade;
	}
	
	
}
